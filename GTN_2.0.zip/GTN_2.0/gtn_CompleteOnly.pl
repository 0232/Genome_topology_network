#!usr/bin/perl
use strict;

# Usage: perl gtn_CompleteOnly.pl <thread number> <outgroup>
# If there is no outgroup, then just: perl gtn_CompleteOnly.pl <thread number>
# Xiao Deng

if(not -d "data_complete"){
	print "Error! Complete genome data file \"data_complete\"does not exist!";
	die;
}
my @data_check=glob("data_complete/*");

if(!@data_check){
	print "Error! No data in \"data_complete\" !";
	die;
}
mkdir "temp" unless -d "temp";

if(-d "temp/data"){
	system("rm -rf temp/data/*");
}else{
	mkdir "temp/data";
}

if(-d "temp/filter"){
	system("rm -rf temp/filter/*");
}else{
	mkdir "temp/filter";
}
system("perl src/FilePrepare.pl 1");
system("perl src/ComToPre.pl");
system("perl src/FamCluster.pl $ARGV[0]");
system("perl src/GetMobileGOGs.pl 3 bootstrap");
system("perl src/GetMobileGOGs.pl 2 distance.meg");
system("perl src/OutFilter.pl $ARGV[1]");
system("perl src/GetMobileGOGs.pl 1 Adjustment/tmp/mobile.list");


