#!usr/bin/perl
use strict;

# Usege: perl gtn_WithDraft.pl <thread number> <outgroup>
# Xiao Deng

if(not -d "data_draft"){
	print "Error! Draft genome data file \"data_draft\"does not exist!";
	die;
}
my @data_check=glob("data_draft/*");


if(!@data_check){
	print "Error! No data in \"data_draft\" !";
	die;
}
mkdir "temp" unless -d "temp";

if(-d "temp/data"){
	system("rm -rf temp/data/*");
}else{
	mkdir "temp/data";
}

if(-d "temp/filter"){
	system("rm -rf temp/filter/*");
}else{
	mkdir "temp/filter";
}


system("perl src/FilePrepare.pl 2");
system("perl src/SyntenyMummer.pl");
system("perl src/synteny1.pl");
system("perl src/synteny2.pl");
system("perl src/synteny3.pl");
system("perl src/DraToPre.pl");
system("perl src/FamCluster.pl $ARGV[0]");
system("perl src/GetMobileGOGs.pl 3 bootstrap");
system("perl src/GetMobileGOGs.pl 2 distance.meg");
system("perl src/OutFilter.pl $ARGV[1]");
system("perl src/GetMobileGOGs.pl 1 Adjustment/tmp/mobile.list");
